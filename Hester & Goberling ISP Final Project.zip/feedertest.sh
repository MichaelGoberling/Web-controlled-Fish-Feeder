#!/bin/sh
sudo python /var/lib/cloud9/feedertest_2.py